```python
# https://github.com/worklifesg/Python-for-Computer-Vision-with-OpenCV-and-Deep-Learning
```


```python
import cv2
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
img = cv2.imread("rainbow.jpg")
```


```python
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x7f4693fed350>




![png](output_3_1.png)



```python
# cancels out back ground colors 
img = cv2.imread("rainbow.jpg", 0)
```


```python
plt.imshow(img, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f4693f95210>




![png](output_5_1.png)



```python
ret1, thresh1 = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
```


```python
ret1
```




    127.0




```python
# changes the background of the gray scale
plt.imshow(thresh1, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f4691f02410>




![png](output_8_1.png)



```python
# changes the color scale from darker to lighter
img2 = cv2.imread("rainbow.jpg", 0)
ret1, thresh1 = cv2.threshold(img2, 127, 255, cv2.THRESH_TRUNC)
plt.imshow(thresh1, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f4691edfb50>




![png](output_9_1.png)



```python
# changes the scale from lighter to darker
img3 = cv2.imread("rainbow.jpg", 0)
ret1, thresh1 = cv2.threshold(img3, 127, 255, cv2.THRESH_TOZERO)
plt.imshow(thresh1, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f4691e4c5d0>




![png](output_10_1.png)



```python
img_r = cv2.imread("crossword.jpg", 0)
plt.imshow(img_r, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f4691db5210>




![png](output_11_1.png)



```python
def show_pic(img):
    fig = plt.figure(figsize = (15,15))
    ax = fig.add_subplot(111)
    ax.imshow(img, cmap = "gray")
```


```python
show_pic(img_r)
```


![png](output_13_0.png)



```python
# This changes the image to black and white kind similar to a pdf file
ret, th1 = cv2.threshold(img_r, 127, 255, cv2.THRESH_BINARY)
show_pic(th1)
```


![png](output_14_0.png)



```python
ret, th1 = cv2.threshold(img_r, 200, 255, cv2.THRESH_BINARY)
show_pic(th1)
```


![png](output_15_0.png)



```python
# this method made the wording more clear but outlined the boxes instead of filling them
th2 = cv2.adaptiveThreshold(img_r, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 8)
```


```python
show_pic(th2)
```


![png](output_17_0.png)



```python
# we overlapped images 1 and 2 to fill in the squares on the crossword properly 
# because of the squares on one of the images are white the fill on the overlap appear grey
blended = cv2.addWeighted(src1 = th1, alpha = 0.6,
                          src2 = th2, beta = 0.4, gamma = 0)
show_pic(blended)
```


![png](output_18_0.png)



```python
# this blended the images to a more focused resolution but the colors are 
# still distorted in some areas due to the color block of the black and white 

th3 = cv2.adaptiveThreshold(img_r, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 8)
blended = cv2.addWeighted(src1=th1,alpha=0.6,
                          src2=th2,beta=0.4,gamma=0)
show_pic(blended)
```


![png](output_19_0.png)



```python

```


```python

```


```python

```
