```python
import cv2
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
def display(img, cmap = "gray"):
    fig = plt.figure(figsize =(12, 10))
    ax = fig.add_subplot(111)
    ax.imshow(img, cmap = "gray")
```


```python
fruit_loops = cv2.imread("fruitloops.jpg", 0)
display(fruit_loops)
```


![png](output_2_0.png)



```python
cereals = cv2.imread('cereals.jpg', 0)
display(cereals)
```


![png](output_3_0.png)



```python
# group 4 snatching using orb to find keypoints in descriptors of the subject matter
orb = cv2.ORB_create()

kp1,des1 = orb.detectAndCompute(fruit_loops, mask=None)
kp2,des2 = orb.detectAndCompute(cereals, mask=None)
```


```python
# Brute Force Matching
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck = True)
matches = bf.match(des1, des2)
```


```python
matches = sorted(matches, key = lambda x:x.distance)
```


```python
fruit_loops_matches= cv2.drawMatches(fruit_loops, kp1, cereals, kp2, matches[:25], None, flags = 2)
```


```python
display(fruit_loops_matches)
```


![png](output_8_0.png)



```python
sift = cv2.SIFT_create()
```


```python
kp1, des1 = sift.detectAndCompute(fruit_loops, None)
kp2, des2 = sift.detectAndCompute(cereals, None)
```


```python
bf = cv2.BFMatcher()
matches = bf.knnMatch(des1, des2, k=2)
```


```python
good = []

for match1, match2 in matches:
    if match1.distance < 0.75*match2.distance:
        good.append([match1])
```


```python
print('Length of total matches:', len(matches))
print('Length of good matches:', len(good))
```

    Length of total matches: 1063
    Length of good matches: 7



```python
# sift_matches allowed the system to go through and display the good matches
sift_matches = cv2.drawMatchesKnn(fruit_loops, kp1, cereals, kp2, good, None, flags=2)
display(sift_matches)
```


![png](output_14_0.png)



```python
sift = cv2.SIFT_create()

kp1, des1 = sift.detectAndCompute(fruit_loops, None)
kp2, des2 = sift.detectAndCompute(cereals, None)
```


```python
flann_index_KDtree = 0
index_params = dict(algorithm=flann_index_KDtree, trees = 5)
search_params = dict(checks=50)
```


```python
# we are comparing the variables of the matches already found
flann = cv2.FlannBasedMatcher(index_params, search_params)
matches = flann.knnMatch(des1, des2, k=2)
good = []

for match1, match2, in matches:
    if match1.distance < 0.75*match2.distance:
        good.append([match1])
```


```python
flann_matches = cv2.drawMatchesKnn(fruit_loops, kp1, cereals, kp2, good, None, flags = 0)
display(flann_matches)
```


![png](output_18_0.png)



```python
# we are using the sift and flann_index functions to sort
# through and show all the features provided in the upcoming steps
sift = cv2.SIFT_create()

kp1, des1 = sift.detectAndCompute(fruit_loops, None)
kp2, des2 = sift.detectAndCompute(cereals, None)
```


```python
flann_index_KDtree = 0
index_params = dict(algorithm = flann_index_KDtree, trees = 5)
search_param = dict(checks = 50)
```


```python
flann = cv2.FlannBasedMatcher(index_params, search_params)

matches = flann.knnMatch(des1, des2, k = 2)
```


```python
matchesMask = [[0,0] for i in range(len(matches))]
```


```python
for i, (match1, match2) in enumerate(matches):
    if match1.distance <0.75*match2.distance:
        matchesMask[i] = [1,0]
        
draw_params = dict(matchColor = (0,255,0),
                  singlePointColor = (255,0,0),
                  matchesMask = matchesMask,
                  flags = 0)
```


```python
flann_matches = cv2.drawMatchesKnn(fruit_loops, kp1, cereals, kp2, matches, None, **draw_params)

display(flann_matches)
```


![png](output_24_0.png)



```python

```


```python

```
