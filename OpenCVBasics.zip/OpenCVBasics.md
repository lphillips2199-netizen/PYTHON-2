```python
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
import cv2
```


```python
img =cv2.imread("Teddy.jpg")
```


```python
# tells you thst it is a numpy document
type(img)
```




    numpy.ndarray




```python
img_wrong = cv2.imread('wrong/path/doesnot/abcdefgh.jpg')
```


```python
type(img_wrong)
```




    NoneType




```python
# plots image and its axes
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x7f85c1913250>




![png](output_6_1.png)



```python
# corrects the color image to it's original color by reversing the color code
fix_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(fix_img)
```




    <matplotlib.image.AxesImage at 0x7f85c184e2d0>




![png](output_8_1.png)



```python
# this creates a gray scale image and size change
img_gray = cv2.imread("Teddy.jpg", cv2.IMREAD_GRAYSCALE)
img_gray.shape
```




    (316, 404)




```python
plt.imshow(img_gray)
```




    <matplotlib.image.AxesImage at 0x7f85be7bb990>




![png](output_10_1.png)



```python
plt.imshow(img_gray, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f85bdf37390>




![png](output_11_1.png)



```python
fix_img.shape
```




    (316, 404, 3)




```python
new_img = cv2.resize(fix_img,(1000,400))
plt.imshow(new_img)
```




    <matplotlib.image.AxesImage at 0x7f85bdeac710>




![png](output_13_1.png)



```python
new_img.shape
```




    (400, 1000, 3)




```python
w_ratio = 0.5
h_ratio = 0.5

new_img = cv2.resize(fix_img, (0,0), fix_img, w_ratio, h_ratio)
```


```python
plt.imshow(new_img)
```




    <matplotlib.image.AxesImage at 0x7f85bde90210>




![png](output_16_1.png)



```python
# used to cut the new image down half of it's original size
new_img.shape
```




    (158, 202, 3)




```python
# flips image on it's vertical axes
flip_img = cv2.flip(fix_img, 0)
plt.imshow(flip_img)
```




    <matplotlib.image.AxesImage at 0x7f85bddffc10>




![png](output_18_1.png)



```python
# flips image down and backwards
flip_img2 = cv2.flip(fix_img, -1)
plt.imshow(flip_img2)
```




    <matplotlib.image.AxesImage at 0x7f85bdd75910>




![png](output_19_1.png)



```python
type(fix_img)
```




    numpy.ndarray




```python
# use this to convert image to it's original color
cv2.imwrite('Teddy.jpg', flip_img)
```




    True




```python

```


```python

```


```python

```
