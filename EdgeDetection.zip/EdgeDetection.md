```python
import cv2
```


```python
import numpy as np
```


```python
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
img = cv2.imread("roses.jpg")
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x7f37a4d78710>




![png](output_3_1.png)



```python
# these are use threshold values that are half the max= 255 so the color is not prominent 
edges = cv2.Canny(image = img, threshold1 = 127, threshold2 = 127)

plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a3dacd10>




![png](output_4_1.png)



```python
# Median value of the image
med_value = np.median(img)
med_value
```




    182.0




```python
# change the lower and upper values of the median value when using the threshold
lower = int(max(0, 0.7*med_value))
upper = int(min(255,1.3*med_value))
edges = cv2.Canny(img, threshold1 = lower, threshold2 = upper)
plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a0d29210>




![png](output_6_1.png)



```python
edges = cv2.Canny(image = img, threshold1 = lower, threshold2 = upper +100)

plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a0cfad50>




![png](output_7_1.png)



```python
# blur function takes away pixals for a better chance of edge detection
blurred_img = cv2.blur(img, ksize = (5,5))

edges = cv2.Canny(image=blurred_img, 
                  threshold1 = lower,
                  threshold2 = upper)
plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a0c62bd0>




![png](output_8_1.png)



```python
# blur function takes away pixals for a better chance of edge detection
# we also alter the size to try and get better results
blurred_img = cv2.blur(img, ksize = (7,7))

edges = cv2.Canny(image=blurred_img, 
                  threshold1 = lower,
                  threshold2 = upper)
plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a0c46390>




![png](output_9_1.png)



```python
# blur function takes away pixals for a better chance of edge detection
# we altered the size and upper threshold
blurred_img = cv2.blur(img, ksize = (5,5))

edges = cv2.Canny(image=blurred_img, 
                  threshold1 = lower,
                  threshold2 = upper + 50)
plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a0ba4b90>




![png](output_10_1.png)



```python
# blur function takes away pixals for a better chance of edge detection
# we altered the size and upper threshold
blurred_img = cv2.blur(img, ksize = (5,5))

edges = cv2.Canny(image=blurred_img, 
                  threshold1 = lower,
                  threshold2 = upper + 100)
plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a0b180d0>




![png](output_11_1.png)



```python
# blur function takes away pixals for a better chance of edge detection
# we altered the size 
blurred_img = cv2.blur(img, ksize = (8,8))

edges = cv2.Canny(image=blurred_img, 
                  threshold1 = lower,
                  threshold2 = upper)
plt.imshow(edges)
```




    <matplotlib.image.AxesImage at 0x7f37a0aead50>




![png](output_12_1.png)



```python

```


```python

```
