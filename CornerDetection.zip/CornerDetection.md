```python
import cv2
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
flat_chess = cv2.imread("Green_chessboard.png")
flat_chess = cv2.cvtColor(flat_chess, cv2.COLOR_BGR2RGB)
plt.imshow(flat_chess)
```




    <matplotlib.image.AxesImage at 0x7f440de06210>




![png](output_1_1.png)



```python
# Apply gray scale to chessboard (template)
gray_flat_chess = cv2.cvtColor(flat_chess, cv2.COLOR_BGR2GRAY)
plt.imshow(gray_flat_chess, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f440d5aaf50>




![png](output_2_1.png)



```python
real_chess = cv2.imread("Chessboard.jpg")
real_chess = cv2.cvtColor(real_chess, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(real_chess)
```




    <matplotlib.image.AxesImage at 0x7f440d522810>




![png](output_4_1.png)



```python
# Apply gray scale to chessboard
gray_real_chess = cv2.cvtColor(real_chess, cv2.COLOR_BGR2GRAY)
plt.imshow(gray_real_chess, cmap = "gray")
```




    <matplotlib.image.AxesImage at 0x7f440bc9c790>




![png](output_5_1.png)



```python
# blocksize = how far out the image stretches
# ksize = test the parameters(you can play with the values and see how it effects the image)
gray = np.float32(gray_flat_chess)
dst = cv2.cornerHarris(src = gray, blockSize = 2, ksize = 3, k = 0.04)

dst = cv2.dilate(dst, None)
```


```python
# Asking to use dst cornerHarris to look at the flat chessboard 
# and anytime you detect a corner make them red
flat_chess[dst>0.01*dst.max()] = [255,0,0]

plt.imshow(flat_chess)
```




    <matplotlib.image.AxesImage at 0x7f440bc0eb90>




![png](output_7_1.png)



```python
# Asking to use dst cornerHarris to look at the real chessboard
# and detect the corners and make them red
gray = np.float32(gray_real_chess)
dst = cv2.cornerHarris(src = gray, blockSize =2, ksize=3, k=0.04)
dst = cv2.dilate(dst, None)

real_chess[dst>0.01*dst.max()] = [255, 0, 0]

plt.imshow(real_chess)
```




    <matplotlib.image.AxesImage at 0x7f440bbfa810>




![png](output_8_1.png)



```python
# Shi-Tomasi Corner Detection
# we are detecting the max level of parameters, quality level,and minimal distance
corners = cv2.goodFeaturesToTrack(gray_flat_chess, 64, 0.01, 10)
```


```python
corners = np.int0(corners)

for i in corners:
    x,y = i.ravel()
    cv2.circle(flat_chess, (x,y),3,(255,0,0), -1)
    
plt.imshow(flat_chess)
```




    <matplotlib.image.AxesImage at 0x7f440bb6f650>




![png](output_10_1.png)



```python
# this is an overlap of the images so they appear green 
corners = cv2.goodFeaturesToTrack(gray_real_chess, 100, 0.01, 10)

corners = np.int0(corners)

for i in corners:
    x,y = i.ravel()
    cv2.circle(real_chess, (x,y),3,(0,255,0), -1)
    
plt.imshow(real_chess)
```




    <matplotlib.image.AxesImage at 0x7f440bad4d50>




![png](output_11_1.png)



```python

```


```python

```
