```python
import cv2
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
img =cv2.imread("Bird.jpg")
```


```python
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x7ff2b6ec0510>




![png](output_2_1.png)



```python
img1 = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(img1)
```




    <matplotlib.image.AxesImage at 0x7ff2b6e75350>




![png](output_4_1.png)



```python
# changes color of image through hue saturation value
img2 = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
```


```python
plt.imshow(img2)
```




    <matplotlib.image.AxesImage at 0x7ff2b4248450>




![png](output_6_1.png)



```python
# changes image color through Hue Saturation Lightness
img3 = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
```


```python
plt.imshow(img3)
```




    <matplotlib.image.AxesImage at 0x7ff2b41b80d0>




![png](output_8_1.png)



```python
img1 = cv2.imread('butterflies.jpeg')
img2 = cv2.imread("Bird.jpg")
```


```python
plt.imshow(img1)
```




    <matplotlib.image.AxesImage at 0x7ff2b4194a50>




![png](output_10_1.png)



```python
img1 = cv2.cvtColor(img1, cv2.COLOR_RGB2BGR)
img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(img1)
```




    <matplotlib.image.AxesImage at 0x7ff2b41060d0>




![png](output_12_1.png)



```python
plt.imshow(img2)
```




    <matplotlib.image.AxesImage at 0x7ff2b406a790>




![png](output_13_1.png)



```python
# resizes the two images to the same scale
img1 = cv2.resize(img1, (1200,1200))
img2 = cv2.resize(img2, (1200,1200))
```


```python
# changes the transparency of the images 
alpha = 0.5
beta = 0.5
```


```python
# combines the two images together 
blended = cv2.addWeighted(img1, alpha, img2, beta, gamma=0)
```


```python
plt.imshow(blended)
```




    <matplotlib.image.AxesImage at 0x7ff2b4055810>




![png](output_17_1.png)



```python
# changes the transparency for the images with alpha/beta function they must always = 1
alpha = 0.8
beta = 0.2

blended1 = cv2.addWeighted(img1, alpha, img2, beta, 0)
plt.imshow(blended1)
```




    <matplotlib.image.AxesImage at 0x7ff2adf2b110>




![png](output_18_1.png)



```python
img1 = cv2.imread("Bird.jpg")
img2 = cv2.imread("butterflies.jpeg")

img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)
img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)

img1 = cv2.resize(img1, (200,200))
```


```python
large_img = img2
small_img = img1

x_offset = 0
y_offset = 0

x_end = x_offset + small_img.shape[1]
y_end = y_offset + small_img.shape[0]

large_img[y_offset:y_end, x_offset:x_end] = small_img

plt.imshow(large_img)
```




    <matplotlib.image.AxesImage at 0x7ff2af7ce610>




![png](output_20_1.png)



```python

```


```python

```
